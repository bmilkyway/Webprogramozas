CREATE DATABASE `uzenetek`
CHARACTER SET utf8 COLLATE utf8_general_ci;

USE `uzenetek`;

CREATE TABLE `uzenetek` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `nev` varchar(45) NOT NULL default '',
  `email` varchar(45) NOT NULL default '',
  `uzenet` varchar(300) NOT NULL default '',
  PRIMARY KEY  (`id`)
)
ENGINE = MYISAM
CHARACTER SET utf8 COLLATE utf8_general_ci;


