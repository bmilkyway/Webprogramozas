
        <?php if(isset($uzenet)) { ?>
            <h1><?= $uzenet ?></h1>
          
        <?php } ?>
