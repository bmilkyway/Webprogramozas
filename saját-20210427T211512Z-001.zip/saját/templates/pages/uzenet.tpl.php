<?php if(isset($uzenet2)) { ?>
           <?= $uzenet2 ?>
          
        <?php } ?>
   
