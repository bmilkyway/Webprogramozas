<h3>Elérhetőségek:</h3>
<h4>Telefon:</h4>
    <ul>
        <li>06 87 571-048 (Mobil)</li>
        <li>06 87 571-057 (Fax)</li>
        <li>30/ 4246-148 (Ügyeletes mobil)</li>
        <li>30/ 2940-782 (Ügyeletes mobil)</li>

    </ul>
<h4>Email:</h4>
    <ul>
        <li>központi email: info@bvu.hu</li>
        <li>fizetőparkolók email: parkolas@bvu.hu</li>
        <li>emető üzemeltetés email: temeto@bvu.hu</li>
    </ul>
<h4>Vagy írjon üzenetet az oldalnak</h4>
    <ul>
        <li> <a href="?oldal=kapcsolatok"> Ide kattintva</a></li>
        <li> Vagy a menüszalagon a kapcsolatok menüpontra kattintva</li>
    </ul>    
<h4> Cím:</h4>
    <ul>
        <li>8258 Badacsonytomaj Fő u. 14.</li>
    </ul>
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10923.813364794942!2d17.514298!3d46.805225!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47690754cad3639d%3A0xb43663d256eb6afb!2sBadacsonytomaj%2C%20F%C5%91%20u.%2014%2C%208258%20Magyarorsz%C3%A1g!5e0!3m2!1shu!2sus!4v1619096253704!5m2!1shu!2sus" width="50" height="50" ></iframe><br>
