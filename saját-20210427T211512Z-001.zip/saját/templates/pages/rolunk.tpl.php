<h2>Cégünkről</h2>
<p>Cégünk  2000. január 01.-én alakult meg, akkor még intézményi formában, és minimális infrastruktúrával alakult meg. Az évek során azonban a feladatkörök bővülése, a megnövekedett elvárások, valamint a gazdaságos üzemeltetés hatására változtatni kellett a cég összetételén és a  társasági formán. Ennek köszönhetően 2009.január 01-től a cégünk, mint Badacsonytomaj VN Kft végzi az üzemeltetői feladatokat.</p>

<p>Cégünk a következő feladatköröket látja el:</p>
<ul>

<li>Közterületen való hulladékgyűjtés</li>
<li>Parkfenntartás </li>
<li>Közterületek takarítása-, fenntartása</li>
<li>Utak karbantartása</li>
<li>Intézmények karbantartása</li>
<li>Forgalomképtelen önkormányzati vagyon karbantartása</li>
<li>Temető üzemeltetés</li>
<li>Városi strandok üzemeltetése</li>
<li>Parkolók üzemeltetése</li>

</ul>

<p>A felsorolt feladatok közül a tulajdonos Önkormányzattal kötött szerződés alapján végezzük a közterületen lévő területek parkfenntartási, közterület tisztítási- ill. hulladékgazdálkodási feladatait, parkolók-, strandok üzemeltetését, intézmények karbantartását.</p>

<p>A fenti feladatokon kívül, kisebb mértékben különböző vállalkozási tevékenységeket is végzünk, melyek a következők lehetnek:</p>
<ul>
<li>Gyommentesítés </li>
<li>Parlagfű-mentesítés </li>
<li> Cserje-, és bozótírtás</li>
<li>Településen belüli teherszállítás </li>
<li> Egyéb gépi munkák</li>

</ul>





