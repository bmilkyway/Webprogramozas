<aside>
<p>Ezúton értesítjük Ügyfeleinket, 
    hogy a kialakult országos járványügyi 
    helyzetre, valamint a kormány ehhez
     kapcsolódó meghozott intézkedéseire
      való tekintettel 2020. november 04-től 
      határozatlan ideig,
     az irodánk ügyeleti rendszerben működik. <p>

<p>Temető ügyintézéssel kapcsolatban személyes ügyintézésre csak  telefonon előre egyeztetett időpontban van lehetőség. </p> 
<p>Időpont egyeztetésre az alábbi telefonszámokon van lehetőség: </p>
<p class="felkover"> 06 87/571-048 illetve 06 30/424-6148</p>
<p>Bármilyen más ügyben a fenti telefonszámok egyikén, vagy e-mailben keressenek minket. </p>
<p>Megértésüket köszönjük. </p>
<p>Vigyázzunk magunkra és vigyázzunk egymásra! </p>
<p>Badacsonytomaj Városüzemeltető Közhasznú Nonprofit Kft. </p>

</aside>

<p class="felkoverdol">Néhány gondolat a VN Kft. működéséről </p>
<p class="felkoverala">Városüzemeltető Nonprofit Kft. legfontosabb feladatai </p>
<p>Badacsonytomaj VN Kft. 2000.-ben alakult, akkor még intézményként működött. Az eltelt 20 év alatt több társasági formában tevékenykedett a szervezet. </p>
<p>A 100% önkormányzati tulajdonú cég 2009.január 01.-től működik a jelenlegi Nonprofit Korlátolt Felelősségű Társasági formában. </p>
<p>A működésünk két fontos alap pillére az elvégzendő feladatok jellege. Ezen szempont alapján elkülönítjük a  Közhasznú-, és Vállakozási Feladatainkat. </p>
<p>Az egyes feladatokat külön szerződések alapján végezzük. Ilyen például a Közhasznúsági szerződés, Vagyonkezelési szerződés ( mintegy 350 ingatlan ), vagy a strandoknál az Üzemeltetési szerződés. Ezen irányvonalak alapján végezzük a feladatainkat. </p>


<ol id="felsorolas"> 
    <li class="betus">Közhasznú Feladatok: ( önkormányzat megbízásából kötelezően ellátandó feladatok )</li>
        <ul>
            <li>Az ökormányzati tulajdonú, belterületi parkok, zöldterületek karbantartása, gondozása, kézi és gépi fűnyírás, levágott fű összegyűjtése, elszállítása  ( közel 11 ha )  </li>
            <li>Közparkok közlekedő útjainak tisztítása, takarítása. </li>
            <li>Parkterületeken és utak melletti fák bokrok, cserjék gondozása, nyírása, sebfelületek lekezelése. </li>
            <li>Virágágyások talajának őszi felásása, tereprendezés, gereblyézés, kora tavaszi virágpalánták elültetése, öntözés, kapálás, nyár elején növények kiszedése, elszállítása, talajlazítás, kapálás, virágágyások elgereblyézése, egynyári virágpalánták beszerzése, helyszínre szállítása, beültetése, öntözés, tápanyagozás, kapálás, növények őszi felszedése.  </li>
            <li>Virágládák egynyári növénnyel történő beültetése, gondozása, föld és növénypótlás, öntözés, tápanyagozás, elszáradt növények őszi kiszedése elszállítása.  </li>
            <li>Évelők tavaszi előkészítése, metszése, gyommentesítése, vegyszerezése, öntözése, tápanyag utánpótlása, téli talajtakaró kialakítása.  </li>
            <li>Élő sövények nyírása, a sövények aljának kapálása, a nyesedék összegyűjtése, elszállítása, a szükséges vegyszerezés és tápanyag utánpótlás.  </li>
            <li>Padok, köztéri berendezések állagmegóvása, karbantartása évente egyszeri festése. (250 db)  </li>
            <li>Fa és fém köztéri szobrok alkalmi karbantartása, tisztítása, állag megóvó festése.  </li>
            <li>Játszóterek kellékeinek (játékok, kerítés, kapuk, kandeláberek ivókutak, szemétgyűjtők stb.) állagmegóvó karbantartása, a növényzet ápolása, vegyszerezése-tekintettel a használókra- tápanyag pótlása,  </li>
            <li>Sor- és parkfák szükség szerinti metszése, növényvédelme, tápanyag pótlása, elszáradt elpusztult fák kivágása vagy kivágatása, azok pótlása.  </li>
            <li>Az önkormányzat tulajdonában lévő belterületi parkokban, belvízelvezető árkokban, játszótereken és közterületeken elszórt szemét folyamatos összeszedése  </li>
            <li>Kiemelt szegélyezéssel megépített önkormányzati tulajdonú és kezelésű utak padkáinak tisztítása. Önkormányzati tulajdonban lévő utak karbantartása ( 88 utca ).  </li>
            <li>Csapadékvíz elvezető árkok gépi és kézi alkalmankénti tisztítása  </li>
            <li>Vízelnyelők – kialakított rácsok- iszapülepítők rendszeres tisztítása. A belvízelvezető árkok tisztítása, vízelvezetés biztosítása.  A kiszedett hordalék felrakása gépjárműre, elszállítása hulladéklerakóra.  </li>
            <li>A közterületre kihelyezett szemétgyűjtők ürítése, karbantartása, a megrongálódott edényzet és tartók javítása, javíttatása. ( mintegy 150 db edény, és a szelektív szigetek )  </li>
            <li>Illegálisan kihelyezett hulladék elszállítása parkolókból, közterületekről, autóbuszvárókból, játszóterekről ( évi 100-150 m3 )  </li>
            <li> Autóbuszvárók, fel és leszállóhelyek ( 20 db ) tisztán tartása. </li>
            <li> Hóeltakarítás és síkosságmentesítés a település útjain, közterein. </li>
            <li>Decemberi közterületi díszkivilágítás felszerelése, felszereltetése, január elején történő lebontása lebontatása. A szükséges raktározás, eszközök karbantartása, pótlása, szállítás, segédmunka biztosítása.  </li>
            <li>Nemzeti és városi ünnepeken zászlók és lobogók elhelyezése, ünnep után az összeszedése, raktározása. </li>
            <li>Fákról a közterületekre és önkormányzat tulajdonában lévő területekre hulló lombozat és az illegálisan oda helyezett nyesedék, hulladék összeszedése, járműre rakása, elszállítása. </li>
            <li>Temetők ( 4 db ), Kolumbárium karbantartása, üzemeltetése </li>
            <li>Sportpálya karbantartása </li>
            <li>Ivókutak, szökőkút karbantartása </li>
            <li>Városháza épület és Egészségház karbantartási feladatai </li>
        </ul>   
    <li class="betus">Vállalkozási feladatok: </li>
        <ul> 
            <li> Strandok, horgászstégek üzemeltetése</li>
            <li> Parkolók üzemeltetése ( 5 db  fizetős )</li>
            <li> BABI rendszer üzemeltetése</li>
            <li> Erdőgazdálkodás:  erdőterületek karbantartás</li>
            <li> Egyéb kisebb feladatok: pl sírrendezés.</li>
            <li> Fuvarozás</li>
        </ul></ol>


<p>A fent felsorolt feladatokon kívül, mindig van egy-egy olyan elvégzendő tevékenység, mely plusz feladatot jelent: 2020.-as évben a közterületek fertőtlenítése </p>
<p>Jelenlegi állományi létszámunk 25 fő, melyből 3 fő irodai dolgozó, 22 fő fizikai dolgozó  van. </p>


<h3 class="alahuz">Cégünk elért eredményei </h3>


<p>Cégünk az elmúlt 10 évben folyamatosan próbálta a rábízott feladatokat maradéktalanul elvégezni. A feladataink nagy többsége munkaerő-, és eszköz igényes.  Eredménynek tekintem azt, hogy az elmúlt években sikerült elérnünk azt, hogy a dolgozói létszám szinte 100 %-ban határozatlan idejű munkaszerződéssel rendelkeznek, és csak szezonális jeleggel, a nyári hónapokban kell plusz létszámot felvennünk (strandok). </p>
<p> A hatékonyabb munkavégzés érdekében több új munkagépet is be tudtunk szerezni, így csökkent a külső vállalkozások bevonása  a napi feladatellátásba ( lánctalpas kotró, kommunális traktor, stb… ).</p>
<p>Szintén pozitívumként éljük meg, hogy a folyamatosan fejlődő strandokat egyre többen látogatják, próbálunk minden évben valami új szolgáltatást nyújtani a vendégeknek. </p>
<p>A helyi lakosságnak is próbáltunk kedvezni azzal, hogy néhány éve tavasszal április, május hónapokban virágpalánta értékesítésbe kezdtünk, melyet az idei évben már ősszel is meghirdettünk. A visszajelzések alapján jó kezdeményezés volt, így a továbbiakban is szeretnénk folytatni, sőt kibővíteni a termékek listáját </p>
<p>Mind közül azonban a legnagyobb sikert annak tekintem, hogy az évek alatt be tudtuk bizonyítani, hogy a Városüzemeltető munkájára szükség van, és hogy az itt dolgozó kollégáim fontos munkát végeznek a településért. </p>


<h3 class="alahuz"> Fontosabb üzemeltetési problémák </h3>

<ol id="masikfelsorol">
<li>Munkaerő hiány: a feladataink pontos és határidőre történő ellátásához dolgozói létszám bővítésre lenne szükség. A munkagépeink használatához , de még az úgynevezett segédmunkákhoz sem találunk sajnos munkaerőt.  Mi nem tudjuk felvenni a versenyt a vállalkozói szektorban lévő bérezéssel. </li>
<li>A településen illegálisan elhelyezett hulladék, mely éves szinten 100-150 m3 mennyiségben keletkezik. </li>
<li>Üdülő ingatlannal rendelkező tulajdonosok sok esetben nem kötnek szerződést hulladék szállításra az NHSZ Tapolca Kft-vel, így az ilyen ingatlanokról a közterületre kerül ki a hulladék, amit valakinek el kell szállítani. </li>
<li>Az ingatlanok előtti zöldsáv, vagy az ingatlanokon keresztül húzódó csapadékvíz elvezető árkok karbantartásának hiánya, melyet az ingatlan tulajdonosának lenne a feladata elvégezni. </li>
</ol>


<h3 class="alahuz">A helyi lakosok, ingatlantulajdonosok és vállalkozók közreműködésének fontossága </h3>
<ol id="masikfelsorol">
<li>Az ingatlan tulajdonosok tartsák rendbe a környezetüket. Itt első sorban az ingatlan előtti zöldterület nyírására, vagy a télen a hóeltakarításra, síkosságmentesítésre gondolok. Az ingatlanról kilógó ágak, gallyak levágása is az ingatantulajdonos felada. </li>
<li>Hulladékszállítási szerződés kötése ( rendszeres vagy alkalmi ürítés, szelektív gyűjtés ), legyen az magánember, vagy vállalkozás. A szelektív szigetek edényzetei nem a vállalkozásoknál kelezkező hulladékért vannak kint, hanem a lakosságnak. Úgy gondolom, aki bevételt termel valamiből, akkor annak viselje a terheit is. A hulladék szállító cégnél van lehetőség vállalkozásoknak is külön szelektív szerződést kötni. </li>


</ol>
<p class="dolt">Érezzük magunkénak a települést! Ne szégyeljünk szólni ha illegális szemetelőt látunk, vagy ha valakit garázdaságon érünk.  </p>
<h3>Legyünk türelmesebbek, segítőkészek egymással, és figyeljünk egymásra. </h3>
<br> 
<h3 class="badacsonyvid">Badacsonytomaji levendulamező:</h3>
<iframe src="https://www.youtube.com/embed/q49N_wQIDkg?autoplay=1&loop=1" width="800" height="500" frameborder="0" allow="autoplay;encrypted-media" allowfullscreen></iframe>
<br>
<iframe src="./video/sajat.mp4" width="500" height="800" type="video/mp4"></iframe>
