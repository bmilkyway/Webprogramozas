<?php if(isset($row)) { ?>
    <?php if($row) { ?>
        <h1>Sikeresen bejelentkezett!</h1>
        <h2><strong><?= $row['csaladi_nev']." ".$row['uto_nev'] ?></strong> jó szórakozást az oldalon! </h2>
  
    <?php } else { ?>
        <h1>A bejelentkezés nem sikerült!</h1>
        <a href="?oldal=belepes" >Próbálja újra!</a>
    <?php } ?>
<?php } ?>
<?php if(isset($errormessage)) { ?>
    <h2><?= $errormessage ?></h2>
<?php } ?>