
<?php
	try {
		
		$pdo = new PDO('mysql:host=localhost;dbname=uzenetek', 'root', '',array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
		$pdo->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
		$sqlkod = "Select id, nev, email, uzenet From uzenetek order by id desc";
		$eredmeny = $pdo->query($sqlkod);
	}
	catch (PDOException $e) {
		echo "Hiba: ".$e->getMessage();
	}      
?>

   <h2>Beérkező üzenetek:</h2>
	<table>
   <tr id="foSor"><td>Név</td> <td>Email-cím</td> <td>Üzenet </td></tr>

	<?php 	foreach($eredmeny as $sor)

		print "<tr><td>" .$sor['nev'] . "</td>"  .   "<td>" . $sor['email'] . "</td>"  . '<td>' .$sor['uzenet'] . "</td></tr>";

	?>
</table>




