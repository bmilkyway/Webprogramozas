<?php session_start(); ?>
<?php if(file_exists('./logicals/'.$nyit['fajl'].'.php')) { include("./logicals/{$nyit['fajl']}.php"); } ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?= $ablakcim['cim']?></title>
	<link rel="stylesheet" href="./styles/stilus.css" type="text/css">
	<?php if(file_exists('./styles/'.$nyit['fajl'].'.css')) { ?><link rel="stylesheet" href="./styles/<?= $nyit['fajl']?>.css" type="text/css"><?php } ?>
	<?php if(file_exists('./js/'.$nyit['fajl'].'.js')) { ?><script type="text/javascript" src="./js/<?= $nyit['fajl']?>.js"> </script> <?php } ?>
</head>


<body>
	<header>	
		<nav>
		<h1><?= $fejlec['cim'] ?></h1>
		</nav>
            <nav id="menu">
		
                <ul>
					<?php foreach ($oldalak as $url => $oldal) { ?>
							<?php if(! isset($_SESSION['login']) && $oldal['menun'][0] || isset($_SESSION['login']) && $oldal['menun'][1]) { ?>
								<li<?= (($oldal == $nyit) ? ' class="active"' : '') ?>>
								<a href="<?= ($url == '/') ? '.' : ('?oldal=' . $url) ?>">
								<?= $oldal['szoveg'] ?></a>
								</li>
								
						<?php } ?>
						<?php } ?>

						<?php if(isset($_SESSION['login'])) { ?><li>Bejlentkezve: <strong><?= $_SESSION['csn']." ".$_SESSION['un']." (".$_SESSION['login'].")" ?></strong></li><?php } ?>

                </ul>		
			</nav>
	
	</header>
    <div id="wrapper">
        <div id="content">
            <?php include("./templates/pages/{$nyit['fajl']}.tpl.php"); ?>
        </div>

		<nav id="oldalsav" >
	   <?php include("./templates/pages/oldalsav.tpl.php"); ?>
     				
							</nav>
    </div>
    <footer >
        <?php if(isset($lablec['copyright'])) { ?>&copy;&nbsp;<?= $lablec['copyright'] ?> <?php } ?>
		&nbsp;
        <?php if(isset($lablec['keszitok'])) { ?><?= $lablec['keszitok']; ?><?php } ?>
    </footer>
</body>
</html>
